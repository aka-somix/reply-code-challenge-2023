"""
prendo i serpenti in ordine di grandezza 
"""
def play_strategy_four():
    # ordino i serpenti per grandezza
    
    # ciclo su tutti i serpenti
    # ciclo sulla lunghezza del serpente
        # se è il primo indice del serpende che inserisco
            # prendo una riga libera della matrice
            # prendo una cella a caso della matrice
        # dal 2 indice alla fine sel serpente
            # dalla cella trovata guardo le celle che ho attorno e prendo quella libera da valore max
            # posiziono la seconda cella del serpente

