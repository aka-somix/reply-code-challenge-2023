def play_helloworld():
    print("STO GIOCANDO!")
