"""
prendo i serpenti in ordine di grandezza e li posiziono sulle celle libere di colonne diverse con valore più grande, spostandolo sempre verso il basso
"""
def play_strategy_two():
    # ordino i serpenti per grandezza
    
    # ciclo su tutti i serpenti
        # cerco una colonna libera
        # cerco la cella con valore max per quella colonna
        # posiziono il serpente spostandolo verso il basso
        
