"""
prendo i serpenti in ordine di grandezza e li posiziono sulle celle libere di righe diverse con valore più grande, spostandolo sempre verso dx
"""
def play_strategy_one():
    # ordino i serpenti per grandezza
    
    # ciclo su tutti i serpenti
        # cerco una riga libera
        # cerco la cella con valore max per quella riga
        # posiziono il serpente spostandolo verso destra
        
