"""
prendo i serpenti in ordine di grandezza 
"""
def play_strategy_five():
    # ordino i serpenti per grandezza
    
    # ciclo su tutti i serpenti
    # ciclo sulla lunghezza del serpente
        # se è il primo indice del serpende che inserisco
            # cerco una cella libera dal massimo valore nella matrice
            # posiziono la cella del serpente
        # dal 2 indice alla fine sel serpente
            # prendo una riga libera della matrice
            # prendo una cella a caso della matrice

