"""
Inserire in questo modulo le strategie di gioco.
AKA un metodo unico da inserire all'interno del metodo play scenario
"""
