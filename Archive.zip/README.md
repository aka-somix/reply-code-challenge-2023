# reply-code-challenge-2023


Come lanciare il gioco:
```
run.sh [INPUT_PATH] [OUTPUT_PATH]
```

Il path è da intendere relativo alla root directory
